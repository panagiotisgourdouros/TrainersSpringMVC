package com.panos.tm.DAO;

import com.panos.tm.api.Trainer;
import java.util.List;

public interface TrainerDAO {
	
	
	List<Trainer> loadTrainers();

	void saveTrainer(Trainer trainer);
	
	Trainer getTrainer(int id);

	void update(Trainer trainer);

	void deleteTrainer(int id);
		
		
		
		
	
			

}
