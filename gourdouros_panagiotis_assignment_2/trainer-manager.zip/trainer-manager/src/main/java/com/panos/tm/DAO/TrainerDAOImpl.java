package com.panos.tm.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.panos.tm.api.Trainer;
import com.panos.tm.rowmapper.TrainerRowMapper;

@Repository
public class TrainerDAOImpl implements TrainerDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Trainer> loadTrainers() {

		String sql = "SELECT * FROM trainers";

		List<Trainer> theListOfTrainers = jdbcTemplate.query(sql, new TrainerRowMapper());

		return theListOfTrainers;
	}

	@Override
	public void saveTrainer(Trainer trainer) {

		Object[] sqlParameters = { trainer.getFname(), trainer.getLname(), trainer.getSubject() };

		String sql = "insert into trainers(fname,lname,subject) values(?,?,?)";

		jdbcTemplate.update(sql, sqlParameters);
		System.out.println("1 record updated..");

	}

	@Override
	public Trainer getTrainer(int id) {

		String sql = "SELECT * FROM trainers WHERE id=?";

		Trainer trainer = jdbcTemplate.queryForObject(sql, new TrainerRowMapper(), id);

		return trainer;
	}

	@Override
	public void update(Trainer trainer) {

		String sql = "UPDATE trainers SET fname=?, lname=?, subject=? WHERE id = ?";
		jdbcTemplate.update(sql, trainer.getFname(), trainer.getLname(), trainer.getSubject(),trainer.getId());
	}

	@Override
	public void deleteTrainer(int id) {
		String sql = "DELETE FROM trainers WHERE ID=?";
		jdbcTemplate.update(sql,id);
		
	}
}
