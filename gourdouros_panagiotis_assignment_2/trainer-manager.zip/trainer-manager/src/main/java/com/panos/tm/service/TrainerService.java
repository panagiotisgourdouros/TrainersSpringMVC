package com.panos.tm.service;
import com.panos.tm.api.Trainer;
import java.util.List;

public interface TrainerService {
	
	List<Trainer> loadTrainers();

	void saveTrainer(Trainer trainer);
	
	Trainer getTrainer(int id);

	void update(Trainer trainer);

	void deleteTrainer(int id);

}
