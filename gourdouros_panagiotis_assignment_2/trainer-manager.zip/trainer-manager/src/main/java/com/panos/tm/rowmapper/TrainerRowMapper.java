package com.panos.tm.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.panos.tm.api.Trainer;

public class TrainerRowMapper implements RowMapper<Trainer> {

	@Override
	public Trainer mapRow(ResultSet rs, int rowNum) throws SQLException {

		Trainer trainer = new Trainer();

		trainer.setId(rs.getInt("id"));
		trainer.setFname(rs.getString("fname"));
		trainer.setLname(rs.getString("lname"));
		trainer.setSubject(rs.getString("subject"));
		return trainer;
	}

}
