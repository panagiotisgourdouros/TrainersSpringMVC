package com.panos.tm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.panos.tm.DAO.TrainerDAO;
import com.panos.tm.api.Trainer;


@Service
public class TrainerServiceImpl implements TrainerService {
	@Autowired
	private TrainerDAO trainerDAO;

	@Override
	public List<Trainer> loadTrainers() {
		
		List<Trainer> trainerList = trainerDAO.loadTrainers();
		
		return trainerList;
	}

	@Override
	public void saveTrainer(Trainer trainer) {
		
		trainerDAO.saveTrainer(trainer);
		
	}

	@Override
	public Trainer getTrainer(int id) {
		
		return trainerDAO.getTrainer(id);
	}

	@Override
	public void update(Trainer trainer) {
		
		
		trainerDAO.update(trainer);
	}

	@Override
	public void deleteTrainer(int id) {
	trainerDAO.deleteTrainer(id);
		
	}
	
	

}
