package com.panos.tm.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;



import com.panos.tm.api.Trainer;
import com.panos.tm.service.TrainerService;


@Controller
public class TrainerController {
	
	@Autowired
	private TrainerService trainerService;

	@GetMapping("/showTrainer")
	public String showTrainerList(Model model) {

		List<Trainer> trainerList = trainerService.loadTrainers();

		for (Trainer tempTrainer : trainerList) {

			System.out.println(tempTrainer);
		}

		model.addAttribute("trainers", trainerList);

		return "trainer-list";
	}

	@GetMapping("/showAddTrainerPage")
	public String addTrainer(Model model) {

		Trainer trainer = new Trainer();
		model.addAttribute("trainer", trainer);

		return "add-trainer";
	}


	@PostMapping("/save-trainer")
	public String saveTrainer(Trainer trainer) {
		
		if(trainer.getId() == 0) {
		
		trainerService.saveTrainer(trainer);
		
		
		
		}else {
			
			trainerService.update(trainer);
			
			
		}

		return "redirect:/showTrainer";
	}
	
	
	
	@GetMapping("/updateTrainer")
	public String updateTrainer(@RequestParam("userId") int id,Model model) {

	
		Trainer TrainerToUpdate = trainerService.getTrainer(id);
		
		model.addAttribute("trainer", TrainerToUpdate);
		
		return "add-trainer";
	}
	
	
	@GetMapping("/deleteTrainer")
	public String deleteTrainer(@RequestParam("userId") int id) {
		
		
		
	trainerService.deleteTrainer(id);

	
		
		
		return "redirect:/showTrainer";
	
	
	}
	
	
}